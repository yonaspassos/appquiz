package com.yona.adivinheacarta;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.Resources;
import android.media.Image;
import android.media.ImageWriter;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ImageView card1;
    private ImageView card2;
    private ImageView card3;
    private Button confirm;
    private TextView result;
    private int selectedCard;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result = findViewById(R.id.ResultText);

        final Button tryAgain = findViewById(R.id.tryAgain);
        tryAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                initDeck();
                confirm.setEnabled(true);
                result.setVisibility(View.INVISIBLE);
                tryAgain.setVisibility(View.INVISIBLE);
            }
        });

        confirm = findViewById(R.id.confirm);
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateResult();
                confirm.setEnabled(false);
                tryAgain.setVisibility(View.VISIBLE);
            }
        });

        card1 = findViewById(R.id.card1);
        card1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                selectedCard = 1;
                card1.setAlpha(0.4f);
                card2.setAlpha(1f);
                card3.setAlpha(1f);
                return false;
            }
        });
        card2 = findViewById(R.id.card2);
        card2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                selectedCard = 2;
                card1.setAlpha(1f);
                card2.setAlpha(0.4f);
                card3.setAlpha(1f);
                return false;
            }
        });
        card3 = findViewById(R.id.card3);
        card3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                selectedCard = 3;
                card1.setAlpha(1f);
                card2.setAlpha(1f);
                card3.setAlpha(0.4f);
                return false;
            }
        });


        initDeck();
    }

    private void calculateResult() {
        Random random = new Random();
        Integer correctPos = random.nextInt(3);
        ImageView card;
        switch (selectedCard) {
            case 1:
                card = card1;
                break;
            case 2:
                card = card2;
                break;
            case 3:
                card = card3;
                break;
            default:
                card = card1;
        }
        if (selectedCard == correctPos) {
            card.setImageResource(R.drawable.correct);
            result.setText ("Parabens! Você acertou!");
        } else {
            card.setImageResource(R.drawable.joker);
            result.setText ("Você tirou Coringa, você errou.");
        }

        result.setVisibility(View.VISIBLE);
    }

    private void initDeck() {
        card1.setImageResource(R.drawable.init);
        card2.setImageResource(R.drawable.init);
        card3.setImageResource(R.drawable.init);
    }
}
